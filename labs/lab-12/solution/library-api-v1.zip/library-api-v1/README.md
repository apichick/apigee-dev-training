This is a Node.js app that we will be using as target backend for the labs of the Apigee developer training. 
